//
//  SPBaseCollectionViewCell.m
//  SPay.base
//
//  Created by wongfish on 15/5/7.
//  Copyright (c) 2015年 wongfish. All rights reserved.
//

#import "SPBaseCollectionViewCell.h"

@implementation SPBaseCollectionViewCell

/**
 *  初始化view
 */
- (void)setupWithViews{
    
}

/**
 *  初始化数据
 */
- (void)setupWithDatas{
    
}

/**
 *  初始化Action
 */
- (void)setupWithAction{
    
}

@end
