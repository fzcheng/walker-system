//
//  NSObject+COCUtilsExtras.h
//  BPLFoundation
//
//  Created by fish.wong on 15/1/31.
//  Copyright (c) 2015年 fish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (COCUtilsExtras)

@end
