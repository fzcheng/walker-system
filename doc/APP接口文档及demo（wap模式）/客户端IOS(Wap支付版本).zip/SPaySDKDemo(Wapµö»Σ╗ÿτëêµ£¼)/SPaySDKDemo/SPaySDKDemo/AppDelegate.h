//
//  AppDelegate.h
//  SPaySDKDemo
//
//  Created by wongfish on 15/6/10.
//  Copyright (c) 2015年 wongfish. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

